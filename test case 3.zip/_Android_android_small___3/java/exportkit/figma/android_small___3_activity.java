
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_small___3
	 *	@date 		Thursday 23rd of March 2023 06:10:00 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class android_small___3_activity extends Activity {

	
	private View _bg__android_small___3_ek2;
	private View rectangle_1;
	private TextView detail;
	private TextView lorem_ipsum_dolor_si;
	private TextView lorem_ipsum_dolor_si_ek1;
	private TextView lorem_ipsum_dolor_si_ek2;
	private TextView lorem_ipsum_dolor_si_ek3;
	private TextView item_3;
	private ImageView mask;
	private ImageView mask_ek1;
	private ImageView image_2;
	private ImageView icon;
	private ImageView shape;
	private ImageView shape_ek1;
	private ImageView vector__stroke_;
	private ImageView vector__stroke__ek1;
	private TextView lorem_ipsum_dolor_sit_amet__consectetur_adipiscing_elit__vivamus_consequat_nulla_vitae_nunc_tempus_feugiat__duis_varius__enim_id_fermentum_tempor__urna_enim_tempus_nisi__vitae_feugiat_eros_nibh_ac_metus__phasellus_placerat_euismod_risus__ac_vehicula_felis_sagittis_ac__sed_dapibus_risus_ac_nibh_dictum_tempus__phasellus_tincidunt_pharetra_mollis__etiam_dictum_quam_pharetra_eros_ultrices__in_interdum_felis_vestibulum__fusce_aliquam_dignissim_lectus__vestibulum_pulvinar_tincidunt_ex__eget_pretium_ex_mollis_at__nam_at_tellus_et_turpis_tempor_ornare__nullam_imperdiet_faucibus_aliquam__fusce_eu_tempor_erat__vivamus_sem_elit__imperdiet_id_justo_eget__mollis_malesuada_augue__nullam_dictum_sodales_imperdiet_;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.android_small___3);

		
		_bg__android_small___3_ek2 = (View) findViewById(R.id._bg__android_small___3_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		detail = (TextView) findViewById(R.id.detail);
		lorem_ipsum_dolor_si = (TextView) findViewById(R.id.lorem_ipsum_dolor_si);
		lorem_ipsum_dolor_si_ek1 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek1);
		lorem_ipsum_dolor_si_ek2 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek2);
		lorem_ipsum_dolor_si_ek3 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek3);
		item_3 = (TextView) findViewById(R.id.item_3);
		mask = (ImageView) findViewById(R.id.mask);
		mask_ek1 = (ImageView) findViewById(R.id.mask_ek1);
		image_2 = (ImageView) findViewById(R.id.image_2);
		icon = (ImageView) findViewById(R.id.icon);
		shape = (ImageView) findViewById(R.id.shape);
		shape_ek1 = (ImageView) findViewById(R.id.shape_ek1);
		vector__stroke_ = (ImageView) findViewById(R.id.vector__stroke_);
		vector__stroke__ek1 = (ImageView) findViewById(R.id.vector__stroke__ek1);
		lorem_ipsum_dolor_sit_amet__consectetur_adipiscing_elit__vivamus_consequat_nulla_vitae_nunc_tempus_feugiat__duis_varius__enim_id_fermentum_tempor__urna_enim_tempus_nisi__vitae_feugiat_eros_nibh_ac_metus__phasellus_placerat_euismod_risus__ac_vehicula_felis_sagittis_ac__sed_dapibus_risus_ac_nibh_dictum_tempus__phasellus_tincidunt_pharetra_mollis__etiam_dictum_quam_pharetra_eros_ultrices__in_interdum_felis_vestibulum__fusce_aliquam_dignissim_lectus__vestibulum_pulvinar_tincidunt_ex__eget_pretium_ex_mollis_at__nam_at_tellus_et_turpis_tempor_ornare__nullam_imperdiet_faucibus_aliquam__fusce_eu_tempor_erat__vivamus_sem_elit__imperdiet_id_justo_eget__mollis_malesuada_augue__nullam_dictum_sodales_imperdiet_ = (TextView) findViewById(R.id.lorem_ipsum_dolor_sit_amet__consectetur_adipiscing_elit__vivamus_consequat_nulla_vitae_nunc_tempus_feugiat__duis_varius__enim_id_fermentum_tempor__urna_enim_tempus_nisi__vitae_feugiat_eros_nibh_ac_metus__phasellus_placerat_euismod_risus__ac_vehicula_felis_sagittis_ac__sed_dapibus_risus_ac_nibh_dictum_tempus__phasellus_tincidunt_pharetra_mollis__etiam_dictum_quam_pharetra_eros_ultrices__in_interdum_felis_vestibulum__fusce_aliquam_dignissim_lectus__vestibulum_pulvinar_tincidunt_ex__eget_pretium_ex_mollis_at__nam_at_tellus_et_turpis_tempor_ornare__nullam_imperdiet_faucibus_aliquam__fusce_eu_tempor_erat__vivamus_sem_elit__imperdiet_id_justo_eget__mollis_malesuada_augue__nullam_dictum_sodales_imperdiet_);
	
		
		//custom code goes here
	
	}
}
	
	