
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_small___2
	 *	@date 		Thursday 23rd of March 2023 06:08:47 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class android_small___2_activity extends Activity {

	
	private View _bg__android_small___2_ek2;
	private View rectangle_1;
	private TextView favorite_games;
	private ImageView background;
	private TextView lorem_ipsum_dolor_si;
	private TextView lorem_ipsum_dolor_si_ek1;
	private TextView item_3_ek1;
	private ImageView mask;
	private ImageView mask_ek1;
	private ImageView image_2;
	private ImageView icon;
	private ImageView background_ek1;
	private TextView lorem_ipsum_dolor_si_ek2;
	private TextView lorem_ipsum_dolor_si_ek3;
	private TextView item_3_ek2;
	private ImageView mask_ek2;
	private ImageView mask_ek3;
	private ImageView image_3;
	private ImageView icon_ek1;
	private TextView home;
	private ImageView shape;
	private TextView heart;
	private ImageView shape_ek1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.android_small___2);

		
		_bg__android_small___2_ek2 = (View) findViewById(R.id._bg__android_small___2_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		favorite_games = (TextView) findViewById(R.id.favorite_games);
		background = (ImageView) findViewById(R.id.background);
		lorem_ipsum_dolor_si = (TextView) findViewById(R.id.lorem_ipsum_dolor_si);
		lorem_ipsum_dolor_si_ek1 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek1);
		item_3_ek1 = (TextView) findViewById(R.id.item_3_ek1);
		mask = (ImageView) findViewById(R.id.mask);
		mask_ek1 = (ImageView) findViewById(R.id.mask_ek1);
		image_2 = (ImageView) findViewById(R.id.image_2);
		icon = (ImageView) findViewById(R.id.icon);
		background_ek1 = (ImageView) findViewById(R.id.background_ek1);
		lorem_ipsum_dolor_si_ek2 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek2);
		lorem_ipsum_dolor_si_ek3 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek3);
		item_3_ek2 = (TextView) findViewById(R.id.item_3_ek2);
		mask_ek2 = (ImageView) findViewById(R.id.mask_ek2);
		mask_ek3 = (ImageView) findViewById(R.id.mask_ek3);
		image_3 = (ImageView) findViewById(R.id.image_3);
		icon_ek1 = (ImageView) findViewById(R.id.icon_ek1);
		home = (TextView) findViewById(R.id.home);
		shape = (ImageView) findViewById(R.id.shape);
		heart = (TextView) findViewById(R.id.heart);
		shape_ek1 = (ImageView) findViewById(R.id.shape_ek1);
	
		
		//custom code goes here
	
	}
}
	
	