
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_small___1
	 *	@date 		Thursday 23rd of March 2023 06:07:59 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class android_small___1_activity extends Activity {

	
	private View _bg__android_small___1;
	private View rectangle_1;
	private ImageView background;
	private TextView input;
	private ImageView shape;
	private TextView games_for_you;
	private ImageView background_ek1;
	private TextView lorem_ipsum_dolor_si;
	private TextView lorem_ipsum_dolor_si_ek1;
	private TextView item_3_ek1;
	private ImageView mask;
	private ImageView mask_ek1;
	private ImageView image_2;
	private ImageView icon;
	private ImageView background_ek2;
	private TextView lorem_ipsum_dolor_si_ek2;
	private TextView lorem_ipsum_dolor_si_ek3;
	private TextView item_3_ek2;
	private ImageView mask_ek2;
	private ImageView mask_ek3;
	private ImageView image_3;
	private ImageView icon_ek1;
	private TextView home;
	private ImageView shape_ek1;
	private TextView heart;
	private ImageView shape_ek2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.android_small___1);

		
		_bg__android_small___1 = (View) findViewById(R.id._bg__android_small___1);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		background = (ImageView) findViewById(R.id.background);
		input = (TextView) findViewById(R.id.input);
		shape = (ImageView) findViewById(R.id.shape);
		games_for_you = (TextView) findViewById(R.id.games_for_you);
		background_ek1 = (ImageView) findViewById(R.id.background_ek1);
		lorem_ipsum_dolor_si = (TextView) findViewById(R.id.lorem_ipsum_dolor_si);
		lorem_ipsum_dolor_si_ek1 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek1);
		item_3_ek1 = (TextView) findViewById(R.id.item_3_ek1);
		mask = (ImageView) findViewById(R.id.mask);
		mask_ek1 = (ImageView) findViewById(R.id.mask_ek1);
		image_2 = (ImageView) findViewById(R.id.image_2);
		icon = (ImageView) findViewById(R.id.icon);
		background_ek2 = (ImageView) findViewById(R.id.background_ek2);
		lorem_ipsum_dolor_si_ek2 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek2);
		lorem_ipsum_dolor_si_ek3 = (TextView) findViewById(R.id.lorem_ipsum_dolor_si_ek3);
		item_3_ek2 = (TextView) findViewById(R.id.item_3_ek2);
		mask_ek2 = (ImageView) findViewById(R.id.mask_ek2);
		mask_ek3 = (ImageView) findViewById(R.id.mask_ek3);
		image_3 = (ImageView) findViewById(R.id.image_3);
		icon_ek1 = (ImageView) findViewById(R.id.icon_ek1);
		home = (TextView) findViewById(R.id.home);
		shape_ek1 = (ImageView) findViewById(R.id.shape_ek1);
		heart = (TextView) findViewById(R.id.heart);
		shape_ek2 = (ImageView) findViewById(R.id.shape_ek2);
	
		
		//custom code goes here
	
	}
}
	
	